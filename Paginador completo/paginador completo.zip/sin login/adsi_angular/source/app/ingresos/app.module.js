(function() {
  'use strict';

  angular.module('app.ingresos', [
    'app.ingresos.controller',
    'app.ingresos.services',
    'app.ingresos.router',
    'app.ingresos.directivas',
  ]);

})();
