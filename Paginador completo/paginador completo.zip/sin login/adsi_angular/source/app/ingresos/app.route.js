(function() {
  'use strict';

  angular.module('app.ingresos.router', []).config(configure);

  //Se inyecta los parametros
  configure.$inject = ['$stateProvider', '$urlRouterProvider'];

  //Se configura las rutas de la aplicación para modelo
  function configure($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/');

    $stateProvider
      .state('listaIngresos', {
        url: '/listaIngresos',
        views: {
          'listaIngresos': {
            template: '<lista-ingresos/>'
          },
          'piepagina': {
            template: '<piepagina/>'
          },
          'encabezado': {
            template: '<encabezado/>'
          }

        }

      }).state('createIngresos', {
        url: '/createIngresos',
        views: {
          'createIngresos': {
            template: '<create-ingresos/>'
          },
          'piepagina': {
            template: '<piepagina/>'
          },
          'encabezado': {
            template: '<encabezado/>'
          }

        }

      }).state('updateIngresos', {
        url: '/updateIngresos/:idIngreso',
        views: {
          'updateIngresos': {
            template: '<update-ingresos/>'

          },
          'piepagina': {
            template: '<piepagina/>'
          },
          'encabezado': {
            template: '<encabezado/>'
          }

        }


      }).state('actaIngresos', {
        url: '/actaIngresos/:idIngreso',
        views: {
          'actaIngresos': {
            template: '<acta-ingresos/>'

          },
          'piepagina': {
            template: '<piepagina/>'
          },
          'encabezado': {
            template: '<encabezado/>'
          }

        }


      });
  };
})();
