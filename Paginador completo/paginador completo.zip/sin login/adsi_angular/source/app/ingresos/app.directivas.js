(function() {
  'use strict';

  angular.module('app.ingresos.directivas', [])
    .directive('listaIngresos', listaIngresos)
    .directive('createIngresos', createIngresos)
    .directive('updateIngresos', updateIngresos)
    .directive('actaIngresos', actaIngresos);

  function listaIngresos() {
    return {
      scope: {},
      templateUrl: 'app/ingresos/listaIngresos.html',
      controller: 'ListaIngresos',
      controllerAs: 'vm'
    };
  }

  function createIngresos() {
    return {
      scope: {},
      templateUrl: 'app/ingresos/crearIngresos.html',
      controller: 'CreateIngresos',
      controllerAs: 'vm'
    };
  }

  function updateIngresos() {
    return {
      scope: {},
      templateUrl: 'app/ingresos/update.html',
      controller: 'UpdateIngresos',
      controllerAs: 'vm'
    }
  }

 function actaIngresos() {
    return {
      scope: {},
      templateUrl: 'app/ingresos/acta.html',
      controller: 'ActaIngresos',
      controllerAs: 'vm'
    }
  }


})();
