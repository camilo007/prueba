(function() {

  'use strict';

  angular.module('app.ingresos.controller', [])
    .controller('ListaIngresos', ListaIngresos)
    .controller('CreateIngresos', CreateIngresos)
    .controller('UpdateIngresos', UpdateIngresos)
    .controller('ActaIngresos', ActaIngresos)
    .controller('IngreCtrl', IngreCtrl)


  ListaIngresos.$inject = ['Ingresos'];

  function ListaIngresos(Ingresos) {
    var vm = this;
    vm.query = {
      limit: 3,
      page: 1
    };
    vm.eliminar = eliminar;
    getIngresos();

    function getIngresos() {
      Ingresos.query().$promise.then(function(data) {
        vm.ingresos = data;
      });
    }
    vm.ingresos = Ingresos.query();

    function eliminar(idIngreso) {
      Ingresos.remove({
          idIngreso: idIngreso
        })
        .$promise.then(function() {
          getIngresos();
        });
    }
  }



  IngreCtrl.$inject = ['Ingresos', '$mdToast', '$location', 'SecurityFilter'];

  function IngreCtrl(Ingresos, IngresoService, $mdToast, $location,
    SecurityFilter) {
    var vm = this;
    vm.query = {
      limit: 6,
      page: 1
    };
    vm.ingresos = Ingresos.query()
  };



  CreateIngresos.$inject = ['Ingresos', '$location', 'Ciudades'];

  function CreateIngresos(Ingresos, $location, Ciudades) {
    var vm = this;

    vm.create = create;
    vm.ciudades = Ciudades.query();


    function create() {
      Ingresos.save(vm.ingresos).$promise.then(function(data) {
        $location.path('/listaIngresos');

      });
    }


  }



  UpdateIngresos.$inject = ['$stateParams', '$location',
    'Ingresos'
  ];

  function UpdateIngresos($stateParams, $location, Ingresos) {
    var vm = this;
    vm.ingreso = Ingresos.get({
      idIngreso: $stateParams.idIngreso
    });


    vm.update = function() {
      Ingresos.update({
        idIngreso: vm.ingreso.idIngreso
      }, vm.ingreso);
      $location.path('/listaIngresos');
      $mdToast.show(
        $mdToast.simple()
        .textContent('Se ha  actualizado el ingreso...')
        .position('bottom right'));

    }
  }

  // Acta.$inject = ['Ingresos', '$stateParams'];
  //
  // function Acta(Ingresos, $stateParams) {
  //   var vm = this;
  //   var id = $stateParams.idIngreso;
  //
  //
  //   }

  ActaIngresos.$inject = ['$stateParams', '$location',
    'Ingresos'
  ];

  function ActaIngresos($stateParams, $location, Ingresos) {
    var vm = this;
    vm.ingres = Ingresos.get({
      idIngreso: $stateParams.idIngreso
    });


    vm.update = function() {
      Ingresos.update({
        idIngreso: vm.ingres.idIngreso
      }, vm.ingres);
      $location.path('/actaIngresos');
      $mdToast.show(
        $mdToast.simple()
        .textContent('Se ha  actualizado el ingreso...')
        .position('bottom right'));

    }
  }


})();
