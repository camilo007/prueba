(function () {
    'use strict';

    angular.module('app.inicio', [
        'app.inicio.router',
        'app.inicio.directivas'
    ]);

})();
